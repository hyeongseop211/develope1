package com.lgy.spring_5_2;

public class pencil4B implements Pencil{

	@Override
	public void use() {
		System.out.println("4B 입니다.");
	}

}
