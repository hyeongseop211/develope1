package com.lgy.spring_5_2;

public interface Pencil {
	public void use() ;
}
