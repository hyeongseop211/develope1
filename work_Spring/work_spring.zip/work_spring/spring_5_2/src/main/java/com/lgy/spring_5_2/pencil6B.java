package com.lgy.spring_5_2;

public class pencil6B implements Pencil{

	@Override
	public void use() {
		System.out.println("6B 입니다.");
	}

}
