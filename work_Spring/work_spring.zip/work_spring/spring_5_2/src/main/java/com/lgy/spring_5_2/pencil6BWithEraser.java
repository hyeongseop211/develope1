package com.lgy.spring_5_2;

public class pencil6BWithEraser implements Pencil{

	@Override
	public void use() {
		System.out.println("6B연필에 지우개가 달린 연필입니다.");
	}

}
