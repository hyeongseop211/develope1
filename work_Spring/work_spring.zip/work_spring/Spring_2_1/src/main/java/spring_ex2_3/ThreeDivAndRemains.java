package spring_ex2_3;

public class ThreeDivAndRemains {
	public static void main(String[] args) {
		Three three = new Three();
		three.setNum(129);
		three.process();
		
		DivAndRemains divandremains =new DivAndRemains();
		divandremains.setNum(77);
		divandremains.process();
	}
}	
