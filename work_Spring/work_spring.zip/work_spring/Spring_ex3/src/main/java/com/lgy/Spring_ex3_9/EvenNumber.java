package com.lgy.Spring_ex3_9;

public class EvenNumber {
	public void process(int num) {
	    int sum = 0; // 짝수들의 합계를 저장할 변수
	    
	    // 1부터 입력받은 정수까지 반복
	    for (int i = 1; i <= num; i++) {
	        // 짝수인 경우 합계에 더함
	        if (i % 2 == 0) {
	            sum += i;
	        }
	    }
	    
	    // 결과 출력
	    System.out.println("1부터 " + num + "까지의 짝수들의 합계: " + sum);
	}
}
