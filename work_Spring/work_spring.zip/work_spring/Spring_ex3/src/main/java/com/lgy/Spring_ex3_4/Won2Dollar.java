package com.lgy.Spring_ex3_4;

public class Won2Dollar {
	public void exchange(int money) {
		double dollar = money /1200;
		System.out.println(money+"원은 $"+dollar+"입니다.");
	}
}
