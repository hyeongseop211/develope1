package com.lgy.Spring_ex3_1;

public class Circle {
	public void area(int radius) {
		System.out.println("원의 면적은 "+(3.14*radius*radius));
	   // double PI = 3.14;
	   // return PI * radius * radius;
	}
}
