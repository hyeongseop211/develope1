package com.lgy.Spring_ex3_7;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;


public class MainRectangle {
	public static void main(String[] args) {

		
String configLoc = "classpath:rectangleCTX.xml";
		
		AbstractApplicationContext ctx = new GenericXmlApplicationContext(configLoc);
		
		MyRectangle myrectangle = ctx.getBean("myrectangle", MyRectangle.class);
		
		myrectangle.pc();
		
	
	}
}
