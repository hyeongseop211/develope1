package com.lgy.Spring_ex3_10;

public class Capital {
	public void alphabet(char endChar) {
	    for (char i = endChar; i >= 'A'; i--) {
	        for (char j = 'A'; j <= i; j++) {
	            System.out.print(j);
	        }
	        System.out.println();
	    }
	}

}
