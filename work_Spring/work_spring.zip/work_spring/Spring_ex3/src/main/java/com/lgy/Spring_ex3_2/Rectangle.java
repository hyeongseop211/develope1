package com.lgy.Spring_ex3_2;

public class Rectangle {
	public void area(int width, int height) {
		System.out.println("사각형의 면적은 "+(width*height));
	}
}
