package com.lgy.Spring_ex3_7;

public class Rectangle {
	public void process(int x, int y) {
		if (x<=200 && x>=100 && y >=100 && y <=200) {
			System.out.println("("+x+","+y+")는 사각형 안에 있습니다.");
		} else {
			System.out.println("("+x+","+y+")는 사각형 안에 없습니다.");

		}
	}
}
