package com.lgy.spring_ex5;

public class Circle {
    private double radius; // 반지름 멤버변수 선언
    
    // 기본 생성자
    public Circle() {
        this.radius = 0.0;
    }
    
    // 매개변수를 가지는 생성자
    public Circle(double radius) {
        this.radius = radius;
    }
    
    // getter 메소드
    public double getRadius() {
        return radius;
    }
    
    // setter 메소드
    public void setRadius(double radius) {
        this.radius = radius;
    }
    
    // 원의 면적을 계산하는 process 메소드
    public double process() {
        final double PI = 3.14;
        return PI * radius * radius;
    }
}

