package com.lgy.spring_ex6_5;

public class NasdaqInfo {
	private Nasdaq nasdaq;

	public Nasdaq getNasdaq() {
		return nasdaq;
	}

	public void setNasdaq(Nasdaq nasdaq) {
		this.nasdaq = nasdaq;
	}
	
}
