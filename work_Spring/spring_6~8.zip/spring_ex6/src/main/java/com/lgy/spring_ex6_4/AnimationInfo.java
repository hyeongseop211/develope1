package com.lgy.spring_ex6_4;

public class AnimationInfo {
	private Animation animation;

	public Animation getAnimation() {
		return animation;
	}

	public void setAnimation(Animation animation) {
		this.animation = animation;
	}
	
	
}
