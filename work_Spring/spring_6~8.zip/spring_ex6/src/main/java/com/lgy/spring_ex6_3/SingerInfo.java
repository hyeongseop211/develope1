package com.lgy.spring_ex6_3;

public class SingerInfo {
	private Singer singer;

	public Singer getSinger() {
		return singer;
	}

	public void setSinger(Singer singer) {
		this.singer = singer;
	}
	
}
