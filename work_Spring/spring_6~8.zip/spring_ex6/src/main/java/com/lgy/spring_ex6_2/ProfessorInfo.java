package com.lgy.spring_ex6_2;


public class ProfessorInfo {
	private Professor professor;

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	
}
