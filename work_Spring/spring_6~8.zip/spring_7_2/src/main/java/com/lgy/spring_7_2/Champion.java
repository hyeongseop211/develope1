package com.lgy.spring_7_2;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Champion  implements InitializingBean, DisposableBean{
	private String name;
	private int tier;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("@# afterPropertiesSet");
	}
	
	@Override
	public void destroy() throws Exception {
		System.out.println("@# destroy");
	}
	
	public Champion(String name, int tier) {
		this.name = name;
		this.tier = tier;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTier() {
		return tier;
	}
	public void setTier(int tier) {
		this.tier = tier;
	}

	
	
}
