package com.lgy.spring_7_1;

public class Champion {
	private String name;
	private int tier;
	
	public Champion(String name, int tier) {
		this.name = name;
		this.tier = tier;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTier() {
		return tier;
	}
	public void setTier(int tier) {
		this.tier = tier;
	}
	
}
