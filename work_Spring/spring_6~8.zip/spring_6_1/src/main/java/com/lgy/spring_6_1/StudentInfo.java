package com.lgy.spring_6_1;

public class StudentInfo {
	private Student student;

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
}
