package com.lgy.spring_8_1;

public class Champion {
	private String name;
	private int tier;
	private int length;
	private int win;
	
	public void getChampionInfo() {
		System.out.println("이름 :"+getName());
		System.out.println("티어 :"+getTier());
		System.out.println("이름길이 :"+getLength());
		System.out.println("승률 :"+getWin());
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTier() {
		return tier;
	}
	public void setTier(int tier) {
		this.tier = tier;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getWin() {
		return win;
	}
	public void setWin(int win) {
		this.win = win;
	}
	
}
